Aby strona działałą poprawnie trzeba wykonać parę kroków

1. Włączmy Apache i MySQL
2. W przeglądarce wchodzimy w localhost/phpmyadmin i tworzymy bazę danych o nazwie miejsca_warte_odwiedzenia i importujemy tak plik z głównego folderu o tej samej nazwie
3. Jeżeli wszystko zostało zrobione poprawnie, strona będzie działać pod adresem localhost/miejsca_warte_odwiedzenia a panel administracyjny localhost/miejsca_warte_odwiedzenia/admin