<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
<div id="main">
<center><p id="naglowek">Miejsca warte odwiedzenia</p>
Projekt wykonali:<br>
Jacek Kluwa<br>
Alicja Świca<br>
Arkadiusz Stelmach<br><br><br>
(?) Aby rozpocząć, wysuń menu nawigacji najeżdżając kursorem na szare pole po lewej stronie.
</center>
<div id="menu">
<img src="bar3.png" style="float: right; border-left: 1px solid black">
<center><br>NAWIGACJA<br><br>
<a href="index.php">Strona tytułowa</a><br><br>
<a href="miejsca.php">Ciekawe miejsca</a>
</center>
</div>
</div>
</body>
</html>
