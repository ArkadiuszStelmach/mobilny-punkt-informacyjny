<?php
Define ('DB_user','root');
Define ('DB_password','');
Define ('DB_host','localhost');
Define ('DB_name','miejsca_warte_odwiedzenia');

$dbc=mysqli_connect (DB_host,DB_user,DB_password,DB_name);
?>