<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
<center>
<p id="naglowek">Panel administracyjny</p>
<form action="Log.php" method="post" ">
<table>
<tr><td>
Login</td><td> <input type="text" name="Log"  />
</td></tr>
<tr><td>
Hasło</td><td> <input type="password" name="Has"  />
</td></tr>
</table><br>
<input type="submit" value="zaloguj">
</form>
</center>
</body>
</html>




