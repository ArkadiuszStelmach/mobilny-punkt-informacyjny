<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
<?php


@$Log = $_REQUEST['Log'];
@$Has = $_REQUEST['Has'];


if($Log =='admin') {

if($Has =='admin'){



echo "Zalogowano <a href='miejsca.php'> Przejdź panelu administratora </a>";


} else {
	
	echo "błędne hasło, <a href=index.php>Powrót do Logowania </a>";
	
	
}




} else {
	echo "błędny login, <a href=index.php>Powrót do Logowania </a>";
	
	
}



?>
</body>
</html>