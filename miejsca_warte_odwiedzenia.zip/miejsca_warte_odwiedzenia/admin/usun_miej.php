<?php

require('config.inc.php');

@$Id_miejsca = $_REQUEST['Id_miejsca'];

 
  $sql = "delete from miejsca where Id_miejsca = $Id_miejsca";

  
  $wynik = mysqli_query($dbc,$sql);



header('Location: http://localhost/miejsca_warte_odwiedzenia/admin/miejsca.php');
?>
